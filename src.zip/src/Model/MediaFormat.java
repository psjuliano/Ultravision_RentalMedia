package Model;

/**
 *
 * @author Priscila
 */
// *** This is an enumerator class. ***
public enum MediaFormat {
    CD, DVD, BLUERAY
}
