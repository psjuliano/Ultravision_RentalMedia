package Model;

/**
 *
 * @author Priscila
 */
public class PlanType {
// *** Attributes ***
    protected int idPlan;
    protected String planName;
    
// **** Getter and Setter ****    
    public int getIdPlan() {
        return idPlan;
    }

    public void setIdPlan(int idPlan) {
        this.idPlan = idPlan;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

}
