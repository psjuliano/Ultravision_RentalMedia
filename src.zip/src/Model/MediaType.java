package Model;

/**
 *
 * @author psouz
 */
public enum MediaType {MOVIE, TV, MUSIC}
