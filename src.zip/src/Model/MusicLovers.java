package Model;

/**
 *
 * @author Marcelo
 */
interface MusicLovers extends MediaInterface {

    // *** Method ***
    public String getBand();

}
